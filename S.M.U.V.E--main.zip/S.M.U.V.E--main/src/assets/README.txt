Assets placeholder

Add your licensed samples in subfolders, e.g.:
- assets/samples/piano/*.wav
- assets/samples/guitar/*.wav
- assets/samples/strings/*.wav
- assets/samples/808/*.wav
- assets/samples/studio/*.wav

Update InstrumentsService to point to your actual sample file paths.
