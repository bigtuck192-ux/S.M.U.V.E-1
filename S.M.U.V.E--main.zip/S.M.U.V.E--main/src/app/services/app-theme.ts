export interface AppTheme {
  name: string;
  primary: string;
  accent: string;
  neutral: string;
  purple: string;
  red: string;
  blue: string;
}
