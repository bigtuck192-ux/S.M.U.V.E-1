import { Component } from '@angular/core';

@Component({
  selector: 'app-performance-mode',
  standalone: true,
  imports: [],
  templateUrl: './performance-mode.component.html',
  styleUrl: './performance-mode.component.css',
})
export class PerformanceModeComponent {}
