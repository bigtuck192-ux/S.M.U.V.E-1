export type PlaybackState = 'stopped' | 'playing' | 'recording';
