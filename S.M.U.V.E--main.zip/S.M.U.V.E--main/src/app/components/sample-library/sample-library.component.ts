import { Component } from '@angular/core';

@Component({
  selector: 'app-sample-library',
  template: '<p>sample-library works!</p>',
  standalone: true,
})
export class SampleLibraryComponent {}
