import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arpeggiator',
  templateUrl: './arpeggiator.component.html',
  styleUrls: ['./arpeggiator.component.css'],
})
export class ArpeggiatorComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
