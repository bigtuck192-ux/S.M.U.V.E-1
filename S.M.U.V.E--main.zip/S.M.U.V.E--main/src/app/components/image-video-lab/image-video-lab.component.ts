import { Component } from '@angular/core';

@Component({
  selector: 'app-image-video-lab',
  standalone: true,
  imports: [],
  templateUrl: './image-video-lab.component.html',
  styleUrls: ['./image-video-lab.component.css'],
})
export class ImageVideoLabComponent {}
